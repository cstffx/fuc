<?php

namespace App\Services\FUC;

class Persona
{
    public ?string $id = null;
    public ?string $identidad_numero = null;
    public ?string $primer_nombre = null;
    public ?string $segundo_nombre = null;
    public ?string $primer_apellido = null;
    public ?string $segundo_apellido = null;
    public ?string $sexo = null;
    public ?int $edad = null;
    public ?string $nombre_padre = null;
    public ?string $nombre_madre = null;
    public ?string $direccion = null;
    public ?int $municipio_residencia_sid = null;
    public ?string $municipio_residencia = null;
    public ?string $municipio_residencia_cod_dpa = null;
    public ?string $municipio_residencia_cod_suin = null;
    public ?int $provincia_residencia_sid = null;
    public ?string $provincia_residencia = null;
    public ?string $provincia_residencia_cod_dpa = null;
    public ?string $provincia_residencia_cod_suin = null;
    public ?string $fecha_act_rid = null;
    public ?string $fecha_act_fuc = null;
    public ?string $fecha_foto = null;
    public ?string $fecha_firma = null;
    public ?bool $fallecido = null;
    public ?string $fecha_act_rec = null;
    public ?string $nacimiento_anno_reg = null;
    public ?string $nacimiento_fecha = null;
    public ?string $nacimiento_tomo = null;
    public ?string $nacimiento_folio = null;
    public ?int $nacimiento_municipio_sid = null;
    public ?string $nacimiento_municipio = null;
    public ?string $nacimiento_municipio_cod_dpa = null;
    public ?string $nacimiento_municipio_cod_suin = null;
    public ?int $nacimiento_provincia_sid = null;
    public ?string $nacimiento_provincia = null;
    public ?string $nacimiento_provincia_cod_dpa = null;
    public ?string $nacimiento_provincia_cod_suin = null;
    public ?int $nacimiento_registro_civil_sid = null;
    public ?string $nacimiento_registro_civil = null;
    public ?string $defuncion_anno_reg = null;
    public ?string $defuncion_fecha = null;
    public ?string $defuncion_tomo = null;
    public ?string $defuncion_folio = null;
    public ?int $defuncion_registro_civil_sid = null;
    public ?string $defuncion_registro_civil = null;
    public ?string $ciudadania_sid = null;
    public ?string $ciudadania = null;
    public ?string $ciudadania_gentilicio = null;
    public ?int $condicion_migratoria_sid = null;
    public ?string $condicion_migratoria = null;

    /**
     * Retorna la concatenacion del nombre y los apellidos.
     * @return string
     */
    public function getNombreCompleto(): string
    {
        $nombre1 = $this->primer_nombre;
        $nombre2 = $this->segundo_nombre;
        $apellido1 = $this->primer_apellido;
        $apellido2 = $this->segundo_apellido;

        return "$nombre1 $nombre2 $apellido1 $apellido2";
    }

    /**
     * Comprueba que $ci, $tomo, $folio coincide con los de la persona actual.
     * @param string $ci
     * @param string $tomo
     * @param string $folio
     * @return bool
     */
    public function checkCI(string $ci, string $tomo, string $folio): bool
    {
        return $this->checkCIPack(new CIPack($ci, $tomo, $folio));
    }

    /**
     * Comprueba que $ci, $tomo, $folio coincide con los de la persona actual.
     * @param CIPack $ci_pack
     * @return bool
     */
    public function checkCIPack(CIPack $ci_pack): bool
    {
        return $this->getCIPack()->isEquals($ci_pack);
    }

    /**
     * @return bool
     */
    public function estaMuerta(): bool
    {
        return $this->fallecido;
    }

    /**
     * @return CIPack
     */
    public function getCIPack(): CIPack
    {
        return new CIPack(
            $this->identidad_numero,
            $this->nacimiento_tomo,
            $this->nacimiento_folio
        );
    }
}
<?php

namespace App\Services\FUC;

class CIPack
{
    public ?string $ci = null;
    public ?string $tomo = null;
    public ?string $folio = null;

    /**
     * @param string|null $ci
     * @param string|null $tomo
     * @param string|null $folio
     */
    public function __construct(
        string $ci = null,
        string $tomo = null,
        string $folio = null)
    {
        $this->ci = $ci;
        $this->tomo = $tomo;
        $this->folio = $folio;
    }

    /**
     * @return string
     */
    public function implode(): string
    {
        return implode("-", [
            trim($this->ci ?? ''),
            trim($this->tomo ?? ''),
            trim($this->folio ?? '')
        ]);
    }

    /**
     * @param CIPack $pack
     * @return string
     */
    public function isEquals(CIPack $pack): string
    {
        return hash_equals($this->implode(), $pack->implode());
    }
}
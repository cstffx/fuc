En services.yml:

```yml
parameters:
  # Ficha unica del ciudadano
  fuc_env: '%env(fuc_env)%'
  fuc_debug: '%env(fuc_debug)%'
  fuc_dev_url: '%env(fuc_dev_url)%'
  fuc_prod_url: '%env(fuc_prod_url)%'
  fuc_auth_token: '%env(fuc_auth_token)%'
  fuc_mock: '%env(fuc_mock)%'

services:
  App\Services\FUC\FucConfigService:
    arguments: [ '%fuc_env%', '%fuc_dev_url%', '%fuc_prod_url%', '%fuc_debug%', '%fuc_auth_token%', '%proxy_http%' ]

  App\Services\FUC\FucService:
    arguments: [ '%fuc_mock%' ]

```

``func_env:`` ``dev`` | ``prod``

Utiliza la caja de arena o el servidor de producción.


``fuc_debug:`` ``true`` | ``false``

Emite mensajes de depuración.


``fuc_dev_url:``

Url cuando el entorno es de desarrollo


``fuc_prod_url:``

Url cuando el entorno es de producción


``fuc_auth_token:``

Token de acceso

``fuc_mock:`` ``true | false``

Si es true se devuelve siempre una persona con número de identidad 00000000000.

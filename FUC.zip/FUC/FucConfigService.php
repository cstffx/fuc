<?php

namespace App\Services\FUC;

use GuzzleHttp\RequestOptions;
use UnexpectedValueException;

class FucConfigService
{
    function __construct(private readonly string $env,
                         private readonly string $devUrl,
                         private readonly string $prodUrl,
                         private readonly string $debug,
                         private readonly string $authToken,
                         private readonly string $proxy)
    {
    }

    public function getOptions(array $extraOptions = [],
                               array $extraHeaders = []): array
    {
        $options = [];
        $headers = $this->getHeaders($extraHeaders);
        $options[RequestOptions::PROXY] = $this->proxy;
        $options[RequestOptions::DEBUG] = $this->debug;
        $options[RequestOptions::HEADERS] = $headers;
        return [...$options, ...$extraOptions];
    }

    public function getHeaders(array $extraHeaders = []): array
    {
        $headers = [];
        $headers['Accept'] = 'application/json';
        $headers['Authorization'] = 'Bearer ' . $this->authToken;
        return [...$headers, ...$extraHeaders];
    }

    /**
     * Genera la url a partir del nivel seleccionado.
     * @param int $level
     * @return string
     */
    public function getLevelUrl(int $level): string
    {
        // Seleccionamos la url base segun el entorno
        $baseUrl = $this->prodUrl;
        if ($this->env === 'dev') {
            $baseUrl = $this->devUrl;
        }

        if('/' != $baseUrl[strlen($baseUrl) - 1]){
            $baseUrl .= '/';
        }

        $baseUrl .= 'nivel';

        return match ($level) {
            0, 1, 2, 3, 4, 10 => $baseUrl . $level,
            default => throw new UnexpectedValueException("$level no es un nivel válido. Los niveles aceptado son: 0, 1,2,3,4 y 10"),
        };
    }

    /**
     * Genera la url a partir del nivel seleccionado.
     * @param string $id
     * @return string
     */
    public function getPhotoUrl(string $id): string
    {
        // Seleccionamos la url base segun el entorno
        $baseUrl = $this->prodUrl;
        if ($this->env === 'dev') {
            $baseUrl = $this->devUrl;
        }

        if('/' != $baseUrl[strlen($baseUrl) - 1]){
            $baseUrl .= '/';
        }

        return "${baseUrl}foto/$id";
    }
}
<?php

namespace App\Services\FUC;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\RequestOptions;
use Zenstruck\Foundry\Factory;

class FucService
{
    const PARAM_CI = 'identidad_numero';
    const PARAM_SIMILAR = 'similar';

    private Client $httpClient;
    private bool $mock;

    function __construct(
        string $mock,
        private readonly FucConfigService $config,
    )
    {
        $this->mock = ("true" === $mock);
        $this->httpClient = new Client();
    }

    /**
     * Retorna la foto de una persona por su id.
     * @param Persona $persona
     * @return string
     * @throws GuzzleException
     */
    public function findPhoto(Persona $persona): string
    {
        if ($this->mock) return "photo";
        return $this->findPhotoById($persona->id);
    }

    /**
     * Retorna la foto de una persona por su id.
     * @param string $id
     * @return string|null
     * @throws GuzzleException
     */
    public function findPhotoById(string $id): ?string
    {
        if($this->mock) return "photo";

        // Headers adicionales para agregar a options.
        $options = [];

        // Configura proxy, debug y headers con autorizacion y accept.
        $options = $this->config->getOptions($options, [
            // Esperamos una imagen
            'Accept' => 'application/octet-stream'
        ]);

        try {
            $url = $this->config->getPhotoUrl($id);
            $response = $this->httpClient->get($url, $options);
            $statusCode = $response->getStatusCode();
            if (200 !== $statusCode) {
                throw new Exception("error");
            }
            $body = $response->getBody();
            return $body->getContents();
        } catch (Exception) {
            return null;
        }
    }

    /**
     * @param string $ci
     * @return Persona|null
     * @throws GuzzleException
     */
    function findPersona(string $ci): ?Persona
    {
        if ($this->mock) return $this->mockPersona();

        // El nivel 10 es quien nos permite encontrar
        // el tomo, folio.
        $data = $this->find($ci, 10);
        if (null === $data) return null;

        return $this->arrayToPersona($data);
    }

    /**
     * @param string $numero_identidad
     * @param int $level
     * @return array|null
     * @throws GuzzleException
     */
    function find(string $numero_identidad, int $level = 0): ?array
    {
        $query = [];
        $query[static::PARAM_CI] = $numero_identidad;
        $query[static::PARAM_SIMILAR] = false;

        // Headers adicionales para agregar a options.
        $options = [];
        $options[RequestOptions::QUERY] = $query;

        // Configura proxy, debug y headers con autorizacion y accept.
        $options = $this->config->getOptions($options);

        try {
            $url = $this->config->getLevelUrl($level);
            $response = $this->httpClient->get($url, $options);

            $body = $response->getBody();
            $content = $body->getContents();

            $data = json_decode($content, true);
            if (!is_array($data)) return null;

            return $data[0] ?? null;
        } catch (Exception) {
            return null;
        }
    }

    /**
     * Retorna  una persona ficticia.
     * @return Persona
     */
    public function mockPersona(): Persona
    {
        $persona = new Persona();
        $persona->id = Factory::faker()->randomKey();
        $persona->identidad_numero = '00000000000';
        $persona->primer_nombre = Factory::faker()->name();
        $persona->segundo_nombre = Factory::faker()->name();
        $persona->primer_apellido = Factory::faker()->name();
        $persona->segundo_apellido = Factory::faker()->name();
        $persona->sexo = 'M';
        $persona->edad = 19;
        $persona->nombre_padre = Factory::faker()->name();
        $persona->nombre_madre = Factory::faker()->name();
        $persona->direccion = Factory::faker()->streetAddress();
        $persona->municipio_residencia_sid = Factory::faker()->numberBetween(100, 300);
        $persona->municipio_residencia = "Boyeros";
        $persona->municipio_residencia_cod_dpa = "22";
        $persona->municipio_residencia_cod_suin = "22";
        $persona->provincia_residencia_sid = "22";
        $persona->provincia_residencia = "22";
        $persona->provincia_residencia_cod_dpa = "22";
        $persona->provincia_residencia_cod_suin = "22";
        $persona->fecha_act_rid = "22";
        $persona->fecha_act_fuc = null;
        $persona->fecha_foto = null;
        $persona->fecha_firma = null;
        $persona->fallecido = null;
        $persona->fecha_act_rec = Factory::faker()->date("d/m/Y");
        $persona->nacimiento_anno_reg = null;
        $persona->nacimiento_fecha = Factory::faker()->date("d/m/Y");
        $persona->nacimiento_tomo = "198";
        $persona->nacimiento_folio = "199";
        $persona->nacimiento_municipio_sid = null;
        $persona->nacimiento_municipio = null;
        $persona->nacimiento_municipio_cod_dpa = null;
        $persona->nacimiento_municipio_cod_suin = null;
        $persona->nacimiento_provincia_sid = null;
        $persona->nacimiento_provincia = null;
        $persona->nacimiento_provincia_cod_dpa = null;
        $persona->nacimiento_provincia_cod_suin = null;
        $persona->nacimiento_registro_civil_sid = null;
        $persona->nacimiento_registro_civil = null;
        $persona->defuncion_anno_reg = null;
        $persona->defuncion_fecha = null;
        $persona->defuncion_tomo = null;
        $persona->defuncion_folio = null;
        $persona->defuncion_registro_civil_sid = null;
        $persona->defuncion_registro_civil = null;
        $persona->ciudadania_sid = 1;
        $persona->ciudadania = "Cubana";
        $persona->ciudadania_gentilicio = "cubano";
        $persona->condicion_migratoria_sid = null;
        $persona->condicion_migratoria = null;
        return $persona;
    }

    /**
     * Convierte un arreglo en un objeto Persona
     * @param array $data
     * @return Persona
     */
    private function arrayToPersona(array $data): Persona
    {
        $persona = new Persona();
        foreach ($data as $key => $value) {
            if (null === $value) continue;
            $persona->$key = $value;
        }
        return $persona;
    }
}

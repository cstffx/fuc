<?php

namespace App\Services\FUC;

use App\Entity\Solicitud;
use App\Services\Response\ImageResponse;
use App\Services\Solicitud\SolicitudStateContext;
use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Exception\GuzzleException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Administra las fotos del usuario.
 */
class FucPhotoManager
{
    /**
     * @param SolicitudStateContext $context
     * @param EntityManagerInterface $manager
     * @param FucService $fuc
     */
    public function __construct(
        private readonly SolicitudStateContext  $context,
        private readonly EntityManagerInterface  $manager,
        private readonly FucService              $fuc)
    {
    }

    /**
     * Lee una foto de la solicitud y la devuelve como una respuesta.
     * @param string $solicitud_id
     * @return ImageResponse
     */
    public function readAsImageResponse(string $solicitud_id): ImageResponse
    {
        $photoFuc = $this->read($solicitud_id);
        return new ImageResponse($photoFuc, "$solicitud_id.jpeg", "jpeg");
    }

    /**
     * Lee una foto de la solicitud.
     * @param int $solicitud_id
     * @return string
     */
    public function read(int $solicitud_id): string
    {
        // Buscamos la solicitud
        $solicitud = $this->manager->find(Solicitud::class, $solicitud_id);
        if (!$solicitud) {
            throw new NotFoundHttpException();
        }

        // Comprobamos que el usuario tiene acceso
        if (!$this->context->canRead($solicitud)) {
            throw new AccessDeniedHttpException();
        }

        $photoFuc = $solicitud->getPhotoFuc();

        if (!$photoFuc) {
            throw new NotFoundHttpException();
        }

        return base64_decode($photoFuc);
    }

    /**
     * Escribe una foto de la persona en la solicitud
     * @param Solicitud $solicitud
     * @param Persona $persona
     * @return void
     * @throws GuzzleException
     */
    public function write(Persona   $persona,
                          Solicitud $solicitud): void
    {
        $photo = $this->fuc->findPhoto($persona);
        if (!$photo) return;

        $photo = base64_encode($photo);
        $solicitud->setPhotoFuc($photo);
    }
}